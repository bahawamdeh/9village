package com.example.shop.config;

import com.example.shop.model.Product;
import com.example.shop.repo.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final ProductRepository productRepository;

    @Override
    public void run(String... args) {
        if (productRepository.count() > 0) return;

        var groups = List.of(
                new String[]{"الأثواب", "https://drive.google.com/"},
                new String[]{"الشالات", "https://drive.google.com/"},
                new String[]{"العباءات", "https://drive.google.com/"},
                new String[]{"القمصان", "https://drive.google.com/"},
                new String[]{"الفساتين", "https://drive.google.com/"},
                new String[]{"الأحزمة", "https://drive.google.com/"},
                new String[]{"الملابس الرجالية", "https://drive.google.com/"},
                new String[]{"الملابس النسائية", "https://drive.google.com/"},
                new String[]{"ملابس الأطفال", "https://drive.google.com/"}
        );

        int imgIdx = 1;
        for (var g : groups) {
            String groupName = g[0];
            String drive = g[1];
            for (int i = 1; i <= 10; i++) {
             
                String img = switch (groupName) {
                    case "الأثواب" -> "/images/thobe1.jpg";
                    case "الشالات" -> "/images/keffiyeh.jpg";
                    case "القمصان" -> "/images/uniform.jpg";
                    case "الفساتين" -> "/images/dress.jpg";
                    default -> "/images/thobe1.jpg";
                };
                double base = 60 + (i * 7);
                productRepository.save(Product.builder()
                        .name(groupName + " - تصميم " + i)
                        .groupName(groupName)
                        .groupDriveUrl(drive)
                        .description("تصميم " + i + " لنفس الصنف: " + groupName + " (اختلاف تطريز/منطقة/لون)")
                        .price(base)
                        .imageUrl(img)
                        .build());
            }
        }
    }
}
