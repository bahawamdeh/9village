package com.example.shop.model;
import jakarta.persistence.*;
 import jakarta.validation.constraints.*;
 import lombok.*;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Product {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @NotBlank private String name;
  @Min(0) private double price;
  private String imageUrl;


  @NotBlank
  private String groupName;

  private String groupDriveUrl;

 
  private String description;
}