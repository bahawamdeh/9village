package com.example.shop.repo;

import com.example.shop.model.Cart;
import com.example.shop.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart, Long> {
    Cart findByUser(User user);
}
