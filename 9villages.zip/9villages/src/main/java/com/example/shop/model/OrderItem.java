package com.example.shop.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OrderItem {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private Long productId; 
  private String productName;
   private double price;
   private int qty;
  @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="order_id") private CustomerOrder order;
}