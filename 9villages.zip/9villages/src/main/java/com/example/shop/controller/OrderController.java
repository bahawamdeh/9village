package com.example.shop.controller;
import com.example.shop.model.*;
import com.example.shop.repo.OrderRepository; 
import jakarta.validation.Valid; 
import lombok.*;
import org.springframework.web.bind.annotation.*; 
import java.time.LocalDateTime; 
import java.util.List;
@RestController @RequiredArgsConstructor @RequestMapping("/api/orders")
public class OrderController {
  @Getter @Setter 
  public static class OrderItemDTO { public Long id; public String name; public double price; 
    public int qty; public String imageUrl; }
  @Getter @Setter 
  public static class CreateOrderDTO { public List<OrderItemDTO> items; public double total; 
    public String paymentId; public String customerName; public String customerPhone; public String customerEmail; }
  private final OrderRepository orderRepository;
  @PostMapping public CustomerOrder create(@Valid @RequestBody CreateOrderDTO dto){
    // الزبون ينشئ الطلب بحالة PENDING ليمر على موافقة/رفض الأدمن
    CustomerOrder order = CustomerOrder.builder().createdAt(LocalDateTime.now()).total(dto.total).
    paymentId(dto.paymentId).status("PENDING")
      .customerName(dto.customerName).customerPhone(dto.customerPhone).customerEmail(dto.customerEmail).build();
    List<OrderItem> items = dto.items.stream().map(i -> OrderItem.builder()
    .productId(i.id).productName(i.name).price(i.price).qty(i.qty).order(order).build()).toList();
    order.setItems(items); return orderRepository.save(order);
  }
  // عرض الطلبات للأدمن عبر /api/admin/orders
}