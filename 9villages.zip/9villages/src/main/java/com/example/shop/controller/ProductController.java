package com.example.shop.controller;
import com.example.shop.model.Product; import com.example.shop.repo.ProductRepository; import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequiredArgsConstructor
public class ProductController {
  private final ProductRepository productRepository;
  @GetMapping(value="/data/products.json", produces=MediaType.APPLICATION_JSON_VALUE)
  public List<Product> productsJsonForFront(){ return productRepository.findAll(); }
  @GetMapping("/api/products") public List<Product> all(){ return productRepository.findAll(); }
  @PostMapping("/api/products") public Product create(@RequestBody Product p){ return productRepository.save(p); }
}