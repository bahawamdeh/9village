package com.example.shop.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AuthController {

    /**
     * Customer الدخول بدون اسم مستخدم/كلمة مرور.
     * عند الضغط على زر "الدخول كزبون" من صفحة login.html
     */
    @GetMapping("/customer-login")
    public String customerLogin(HttpServletRequest request, HttpServletResponse response) {
        // IMPORTANT: setting the authentication in SecurityContextHolder alone is not always
        // persisted to the session. We explicitly store it in the HttpSession.
        var auth = new UsernamePasswordAuthenticationToken(
                "customer",
                null,
                List.of(new SimpleGrantedAuthority("ROLE_CUSTOMER"))
        );
        var context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(auth);
        SecurityContextHolder.setContext(context);
        request.getSession(true).setAttribute(
                HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
                context
        );
        return "redirect:/index.html";
    }
}
