package com.example.shop.controller;

import com.example.shop.model.CustomerOrder;
import com.example.shop.repo.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/orders")
public class AdminOrderController {

    private final OrderRepository orderRepository;

    @GetMapping
    public List<CustomerOrder> list() {
        return orderRepository.findAll();
    }

    @PutMapping("/{id}/status")
    public CustomerOrder updateStatus(@PathVariable Long id, @RequestParam String status) {
        CustomerOrder order = orderRepository.findById(id).orElseThrow();
        // نسمح بحالات محددة فقط
        switch (status) {
            case "PENDING", "APPROVED", "REJECTED" -> order.setStatus(status);
            default -> throw new IllegalArgumentException("Invalid status: " + status);
        }
        return orderRepository.save(order);
    }

    @PutMapping("/{id}/approve")
    public CustomerOrder approve(@PathVariable Long id) {
        CustomerOrder order = orderRepository.findById(id).orElseThrow();
        order.setStatus("APPROVED");
        return orderRepository.save(order);
    }

    @PutMapping("/{id}/reject")
    public CustomerOrder reject(@PathVariable Long id) {
        CustomerOrder order = orderRepository.findById(id).orElseThrow();
        order.setStatus("REJECTED");
        return orderRepository.save(order);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        orderRepository.deleteById(id);
    }
}
