package com.example.shop.controller;

import com.example.shop.model.Product;
import com.example.shop.repo.ProductRepository;
import lombok.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/catalog")
public class AdminCatalogController {

    private final ProductRepository productRepository;

    @Getter @Setter
    public static class GroupInfo {
        private String groupName;
        private String groupDriveUrl;
    }

    @Getter @Setter
    public static class DesignPayload {
        private Long id; // optional for update
        private String groupName;
        private String groupDriveUrl;
        private String name;
        private String description;
        private double price;
        private String imageUrl;
    }

    @GetMapping("/groups")
    public List<GroupInfo> groups() {
        Map<String, String> map = new LinkedHashMap<>();
        for (Product p : productRepository.findAll()) {
            map.putIfAbsent(p.getGroupName(), p.getGroupDriveUrl());
        }
        List<GroupInfo> out = new ArrayList<>();
        for (var e : map.entrySet()) {
            GroupInfo gi = new GroupInfo();
            gi.setGroupName(e.getKey());
            gi.setGroupDriveUrl(e.getValue());
            out.add(gi);
        }
        return out;
    }


    @GetMapping("/designs")
    public List<Product> designs(@RequestParam String groupName) {
        return productRepository.findAll().stream()
                .filter(p -> groupName.equals(p.getGroupName()))
                .toList();
    }

  
    @PostMapping("/designs")
    public Product addDesign(@RequestBody DesignPayload payload) {
        Product p = Product.builder()
                .groupName(payload.getGroupName())
                .groupDriveUrl(payload.getGroupDriveUrl())
                .name(payload.getName())
                .description(payload.getDescription())
                .price(payload.getPrice())
                .imageUrl(payload.getImageUrl())
                .build();
        return productRepository.save(p);
    }

    @PutMapping("/designs/{id}")
    public Product updateDesign(@PathVariable Long id, @RequestBody DesignPayload payload) {
        Product p = productRepository.findById(id).orElseThrow();
        if (payload.getGroupName() != null) p.setGroupName(payload.getGroupName());
        if (payload.getGroupDriveUrl() != null) p.setGroupDriveUrl(payload.getGroupDriveUrl());
        if (payload.getName() != null) p.setName(payload.getName());
        if (payload.getDescription() != null) p.setDescription(payload.getDescription());
        if (payload.getImageUrl() != null) p.setImageUrl(payload.getImageUrl());
        p.setPrice(payload.getPrice());
        return productRepository.save(p);
    }

    @DeleteMapping("/designs/{id}")
    public void deleteDesign(@PathVariable Long id) {
        productRepository.deleteById(id);
    }

   
    @PutMapping("/groups/drive")
    public void updateGroupDrive(@RequestParam String groupName, @RequestParam String driveUrl) {
        List<Product> list = productRepository.findAll().stream()
                .filter(p -> groupName.equals(p.getGroupName()))
                .toList();
        for (Product p : list) {
            p.setGroupDriveUrl(driveUrl);
            productRepository.save(p);
        }
    }
}
