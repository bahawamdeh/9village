package com.example.shop.controller;

import com.example.shop.model.*;
import com.example.shop.repo.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final UserRepository userRepo;
    private final CartRepository cartRepo;
    private final CartItemRepository cartItemRepo;
    private final ProductRepository productRepo;

    public CartController(UserRepository userRepo, CartRepository cartRepo,
                          CartItemRepository cartItemRepo, ProductRepository productRepo) {

        this.userRepo = userRepo;
        this.cartRepo = cartRepo;
        this.cartItemRepo = cartItemRepo;
        this.productRepo = productRepo;
    }

    @PostMapping("/add")
    public String addToCart(@RequestParam String username,
                            @RequestParam Long productId,
                            @RequestParam int qty) {

        User user = userRepo.findByUsername(username);

        Cart cart = cartRepo.findByUser(user);
        if (cart == null) {
            cart = new Cart();
            cart.setUser(user);
            cartRepo.save(cart);
        }

        Product product = productRepo.findById(productId).orElse(null);

        CartItem item = new CartItem();
        item.setCart(cart);
        item.setProduct(product);
        item.setQuantity(qty);

        cartItemRepo.save(item);

        return "added";
    }
}
