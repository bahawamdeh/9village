package com.example.shop.controller;

import com.example.shop.model.Product;
import com.example.shop.repo.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequiredArgsConstructor
public class CatalogController {

    private final ProductRepository productRepository;

    public record DesignDTO(Long id, String name, String description, double price, String imageUrl) {}
    public record GroupDTO(String groupName, String groupDriveUrl, List<DesignDTO> designs) {}

    @GetMapping("/api/catalog")
    public List<GroupDTO> catalog() {
        List<Product> all = productRepository.findAll();
        // group by groupName
        Map<String, List<Product>> grouped = new LinkedHashMap<>();
        for (Product p : all) {
            grouped.computeIfAbsent(p.getGroupName(), k -> new ArrayList<>()).add(p);
        }
        List<GroupDTO> out = new ArrayList<>();
        for (var entry : grouped.entrySet()) {
            var list = entry.getValue();
            String drive = list.stream().map(Product::getGroupDriveUrl).filter(Objects::nonNull).findFirst().orElse("");
            List<DesignDTO> designs = list.stream()
                    .sorted(Comparator.comparing(Product::getId))
                    .map(p -> new DesignDTO(p.getId(), p.getName(), p.getDescription(), p.getPrice(), p.getImageUrl()))
                    .toList();
            out.add(new GroupDTO(entry.getKey(), drive, designs));
        }
        return out;
    }
}
