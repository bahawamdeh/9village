package com.example.shop.repo;
import com.example.shop.model.CustomerOrder; import org.springframework.data.jpa.repository.JpaRepository;
public interface OrderRepository extends JpaRepository<CustomerOrder, Long> {}