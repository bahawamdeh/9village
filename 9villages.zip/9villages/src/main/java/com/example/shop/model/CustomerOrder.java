package com.example.shop.model;
import jakarta.persistence.*; import lombok.*; import java.time.LocalDateTime; import java.util.List;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CustomerOrder {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) 
  private Long id;
  private LocalDateTime createdAt;
   private double total;
   private String status;
   private String paymentId;
  private String customerName;
   private String customerPhone;
    private String customerEmail;
  @OneToMany(mappedBy="order", cascade=CascadeType.ALL, orphanRemoval=true)
   private List<OrderItem> items;
}