(async function(){
  const groupsRoot = document.getElementById('groups');
  const details = document.getElementById('details');
  const designsRoot = document.getElementById('designs');
  const title = document.getElementById('details-title');
  const driveLink = document.getElementById('drive-link');
  const closeBtn = document.getElementById('close-details');

  if (!groupsRoot) return;

  function esc(s){return String(s??'').replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));}

  let catalog = [];
  try {
    const res = await fetch('/api/catalog');
    catalog = await res.json();
  } catch (e) {
    groupsRoot.innerHTML = '<p>تعذر تحميل المنتجات.</p>';
    return;
  }

  // نتأكد نعرض فقط 9 أصناف (حتى لو الداتا زادت)
  catalog = catalog.slice(0, 9);

  function renderGroups(){
    groupsRoot.innerHTML='';
    catalog.forEach((g, idx)=>{
      const cover = (g.designs && g.designs[0] && g.designs[0].imageUrl) ? g.designs[0].imageUrl : 'images/placeholder.png';
      const card = document.createElement('div');
      card.className='card group-card';
      card.id = g.groupName;
      card.innerHTML = `
        <img src="${esc(cover)}" alt="${esc(g.groupName)}">
        <div class="card-body">
          <h5>${esc(g.groupName)}</h5>
          <div class="muted">10 تصاميم</div>
          <button class="btn" type="button">عرض التصاميم</button>
        </div>`;
      card.querySelector('button').addEventListener('click', ()=>openGroup(idx));
      groupsRoot.appendChild(card);
    });
  }

  function openGroup(index){
    const g = catalog[index];
    title.textContent = g.groupName;
    driveLink.href = g.groupDriveUrl || 'https://drive.google.com/';
    designsRoot.innerHTML='';

    (g.designs||[]).slice(0,10).forEach(d=>{
      const card = document.createElement('div');
      card.className='card';
      card.innerHTML = `
        <img src="${esc(d.imageUrl||'images/placeholder.png')}" alt="${esc(d.name)}">
        <div class="card-body">
          <h5>${esc(d.name)}</h5>
          <p class="muted">${esc(d.description||'')}</p>
          <div class="price">${Number(d.price||0).toFixed(2)} $</div>
          <button class="btn" type="button">أضف إلى السلة 🛒</button>
        </div>`;
      card.querySelector('button').addEventListener('click', ()=>{
        if (window.addToCart){
          window.addToCart({id:d.id,name:d.name,price:d.price,imageUrl:d.imageUrl});
          const msg=document.createElement('div');
          msg.textContent='✅ تمت الإضافة إلى السلة';
          Object.assign(msg.style,{position:'fixed',bottom:'20px',right:'20px',background:'#28a745',color:'#fff',padding:'12px 20px',borderRadius:'8px',fontWeight:'600',boxShadow:'0 2px 10px rgba(0,0,0,.2)',zIndex:'1000'});
          document.body.appendChild(msg);
          setTimeout(()=>msg.remove(),1500);
        }
      });
      designsRoot.appendChild(card);
    });

    details.classList.remove('hidden');
    details.scrollIntoView({behavior:'smooth',block:'start'});
  }

  closeBtn?.addEventListener('click', ()=>details.classList.add('hidden'));

  renderGroups();

  // لو في hash بالـ URL افتح الصنف مباشرة
  const hash = decodeURIComponent((location.hash||'').replace('#',''));
  if (hash){
    const idx = catalog.findIndex(g=>g.groupName===hash);
    if (idx>=0) openGroup(idx);
  }
})();
