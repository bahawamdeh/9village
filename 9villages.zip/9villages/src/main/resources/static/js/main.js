document.addEventListener('DOMContentLoaded',()=>{
  const featured=document.getElementById('featured');const productsGrid=document.getElementById('products');
  fetch('data/products.json').then(r=>r.json()).then(list=>{
    const target=featured||productsGrid;if(!target)return;
    list.forEach(p=>{const card=document.createElement('div');card.className='card';card.innerHTML=`
      <img src="${p.imageUrl||'images/placeholder.png'}" alt="${p.name}">
      <div class="card-body"><h5>${p.name}</h5><div class="price">${p.price} $</div>
      <button class="btn" onclick='addToCartWithMessage(${JSON.stringify(p)})'>أضف إلى السلة 🛒</button></div>`;
      target.appendChild(card);});}).catch(()=>{
        if(featured)featured.innerHTML='<p>تعذر تحميل المنتجات.</p>';
        if(productsGrid)productsGrid.innerHTML='<p>تعذر تحميل المنتجات.</p>';
      });
  if(document.getElementById('cart-root')){window.renderCartTable();}
});
function addToCartWithMessage(product){addToCart(product);const msg=document.createElement('div');msg.textContent='✅ تمت الإضافة إلى السلة بنجاح';Object.assign(msg.style,{position:'fixed',bottom:'20px',right:'20px',background:'#28a745',color:'#fff',padding:'12px 20px',borderRadius:'8px',fontWeight:'600',boxShadow:'0 2px 10px rgba(0,0,0,.2)',zIndex:'1000'});document.body.appendChild(msg);setTimeout(()=>msg.remove(),2000);}