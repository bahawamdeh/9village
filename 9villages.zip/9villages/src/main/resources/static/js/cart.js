const CART_KEY='pts_cart';
function getCart(){try{return JSON.parse(localStorage.getItem(CART_KEY))||[]}catch{return[]}}
function saveCart(c){localStorage.setItem(CART_KEY,JSON.stringify(c))}
function addToCart(p,qty=1){const c=getCart();const i=c.findIndex(x=>x.id===p.id);
  if(i>=0){c[i].qty+=qty}else{c.push({id:p.id,name:p.name,price:p.price,imageUrl:p.imageUrl,qty})
  }saveCart(c);return c}
function removeFromCart(id){let c=getCart().filter(i=>i.id!==id);saveCart(c);return c}
function updateQty(id,qty){qty=Math.max(1,parseInt(qty||1,10));
  const c=getCart().map(i=>i.id===id?{...i,qty}:i);
saveCart(c);return c}
function clearCart(){saveCart([])}
function cartTotal(){return getCart().reduce((s,i)=>s+i.price*i.qty,0)}
function renderCartTable(){const root=document.getElementById('cart-root');
  const summary=document.getElementById('summary');
  const totalEl=document.getElementById('cart-total');const cart=getCart();
  if(!root)return;if(!cart.length)
    {root.innerHTML=`<div class="empty">السلة فارغة. <a class="btn" href="products.html">تسوق الآن</a></div>`;summary.style.display='none';return}let rows=cart.map(i=>`
<tr>
  <td><img src="${i.imageUrl}" style="width:70px;height:70px;object-fit:cover;border-radius:8px"></td>
  <td>${i.name}</td>
  <td>${i.price} $</td>
  <td class="cart-actions">
    <input class="qty" type="number" min="1" value="${i.qty}" onchange="onQtyChange(${i.id}, this.value)">
    <button class="btn" onclick="onRemove(${i.id})">حذف</button>
  </td>
  <td>${(i.price*i.qty).toFixed(2)} $</td>
</tr>`).join('');root.innerHTML=`
<table class="cart-table">
  <thead><tr><th>الصورة</th><th>المنتج</th><th>السعر</th><th>الكمية</th><th>الإجمالي</th></tr></thead>
  <tbody>${rows}</tbody>
</table>`;totalEl.textContent=cartTotal().toFixed(2);summary.style.display='flex'}
function onQtyChange(id,qty){updateQty(id,qty);renderCartTable();if(typeof refreshPayPal==='function')refreshPayPal()}
function onRemove(id){removeFromCart(id);renderCartTable();if(typeof refreshPayPal==='function')refreshPayPal()}
window.addToCart=addToCart;window.getCart=getCart;window.cartTotal=cartTotal;
window.clearCart=clearCart;window.renderCartTable=renderCartTable;
window.onQtyChange=onQtyChange;window.onRemove=onRemove;