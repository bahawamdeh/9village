let paypalButtons;
function mountPayPal(){
  const container=document.getElementById('paypal-container');if(!container)return;
  const total=(window.cartTotal?window.cartTotal():0).toFixed(2);
  container.innerHTML='';
  paypal.Buttons({
    style:{layout:'vertical',color:'gold',shape:'rect',label:'paypal'},
    createOrder:(data,actions)=>actions.order.create({purchase_units:[{amount:{value:total,currency_code:'USD'},
      description:'Palestine Tailor Shop Order'}]}),
    onApprove:async (data,actions)=>{
      const details=await actions.order.capture();
      const items=(window.getCart?window.getCart():[]);
      const total=(window.cartTotal?window.cartTotal():0);
      await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify
        ({items:items.map(i=>({id:i.id,name:i.name,price:i.price,qty:i.qty,imageUrl:i.imageUrl})),total:total
        ,paymentId:details.id,customerName:'',customerPhone:'',customerEmail:''})});
      alert('✅ تم الدفع وتسجيل الطلب بنجاح! رقم العملية: '+details.id);
      if(window.clearCart)window.clearCart();if(window.renderCartTable)window.renderCartTable();mountPayPal();
    },
    onError:(err)=>{console.error(err);alert('❌ حدث خطأ أثناء الدفع. حاول مجددًا.');}
  }).render('#paypal-container');
}
function refreshPayPal(){mountPayPal()}
document.addEventListener('DOMContentLoaded',mountPayPal);