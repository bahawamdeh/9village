(async function(){
  const groupSelect = document.getElementById('group-select');
  const driveGroup = document.getElementById('drive-group');
  const designForm = document.getElementById('design-form');
  const driveForm = document.getElementById('drive-form');
  const ordersRoot = document.getElementById('orders');
  const designsRoot = document.getElementById('designs-list');

  function esc(s){
    return String(s ?? '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'
    }[c]));
  }

  async function loadGroups(){
    const res = await fetch('/api/admin/catalog/groups');
    const groups = await res.json();
    const opts = groups.map(g => `<option value="${esc(g.groupName)}" data-drive="${esc(g.groupDriveUrl||'')}">${esc(g.groupName)}</option>`).join('');
    groupSelect.innerHTML = opts;
    driveGroup.innerHTML = opts;
    // set default drive url
    const first = driveGroup.querySelector('option');
    if(first){
      document.getElementById('drive-url').value = first.getAttribute('data-drive') || '';
    }
  }

  async function loadDesignsForSelectedGroup(){
    if(!designsRoot) return;
    const groupName = groupSelect.value;
    if(!groupName){ designsRoot.innerHTML = ''; return; }

    const qs = new URLSearchParams({groupName});
    const res = await fetch('/api/admin/catalog/designs?' + qs.toString());
    if(!res.ok){
      designsRoot.innerHTML = '<p class="muted">تعذر تحميل التصاميم.</p>';
      return;
    }
    const designs = await res.json();
    if(!designs.length){
      designsRoot.innerHTML = '<p class="muted">لا توجد تصاميم لهذا الصنف بعد.</p>';
      return;
    }
    designsRoot.innerHTML = designs.map(d => `
      <div class="design-row">
        <div>
          <strong>${esc(d.name)}</strong>
          <div class="muted">${esc(d.description||'')}</div>
          <div class="muted">${Number(d.price||0).toFixed(2)}$</div>
        </div>
        <button class="btn" data-del-design="${d.id}">حذف</button>
      </div>
    `).join('');

    designsRoot.querySelectorAll('button[data-del-design]').forEach(btn => {
      btn.addEventListener('click', async ()=>{
        const id = btn.getAttribute('data-del-design');
        if(!confirm('تأكيد حذف هذا التصميم؟')) return;
        const delRes = await fetch(`/api/admin/catalog/designs/${id}`, {method:'DELETE'});
        if(!delRes.ok){ alert('❌ فشل الحذف'); return; }
        await loadDesignsForSelectedGroup();
      });
    });
  }

  driveGroup?.addEventListener('change', ()=>{
    const opt = driveGroup.selectedOptions[0];
    document.getElementById('drive-url').value = opt?.getAttribute('data-drive') || '';
  });

  designForm?.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const groupName = groupSelect.value;
    const opt = groupSelect.selectedOptions[0];
    const groupDriveUrl = opt?.getAttribute('data-drive') || '';

    const payload = {
      groupName,
      groupDriveUrl,
      name: document.getElementById('design-name').value,
      description: document.getElementById('design-desc').value,
      price: Number(document.getElementById('design-price').value || 0),
      imageUrl: document.getElementById('design-image').value || null
    };

    const res = await fetch('/api/admin/catalog/designs', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });

    if(res.ok){
      alert('✅ تمت إضافة التصميم');
      designForm.reset();
      await loadGroups();
      await loadDesignsForSelectedGroup();
    } else {
      alert('❌ فشل إضافة التصميم');
    }
  });

  driveForm?.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const groupName = driveGroup.value;
    const driveUrl = document.getElementById('drive-url').value;
    const qs = new URLSearchParams({groupName, driveUrl});
    const res = await fetch('/api/admin/catalog/groups/drive?' + qs.toString(), {method:'PUT'});
    if(res.ok){
      alert('✅ تم تحديث رابط Google Drive');
      await loadGroups();
    } else {
      alert('❌ فشل تحديث الرابط');
    }
  });

  async function loadOrders(){
    if(!ordersRoot) return;
    const res = await fetch('/api/admin/orders');
    const orders = await res.json();
    if(!orders.length){
      ordersRoot.innerHTML = '<p class="muted">لا توجد طلبات.</p>';
      return;
    }
    ordersRoot.innerHTML = orders.map(o => {
      const items = (o.items||[]).map(i => `<li>${esc(i.productName)} × ${i.qty} — ${Number(i.price).toFixed(2)}$</li>`).join('');
      return `
        <div class="order-card">
          <div class="order-head">
            <strong>طلب #${o.id}</strong>
            <span class="status">${esc(o.status||'')}</span>
          </div>
          <div class="muted">${esc(o.customerName||'')} — ${esc(o.customerPhone||'')}</div>
          <div class="muted">الإجمالي: ${Number(o.total||0).toFixed(2)}$</div>
          <ul class="order-items">${items}</ul>
          <div class="order-actions">
            <button class="btn" data-approve="${o.id}">موافقة</button>
            <button class="btn" data-reject="${o.id}">رفض</button>
            <button class="btn" data-del="${o.id}">حذف</button>
          </div>
        </div>`;
    }).join('');

    // bind actions
    ordersRoot.querySelectorAll('button[data-approve]').forEach(btn => {
      btn.addEventListener('click', async ()=>{
        const id = btn.getAttribute('data-approve');
        await fetch(`/api/admin/orders/${id}/approve`, {method:'PUT'});
        await loadOrders();
      });
    });
    ordersRoot.querySelectorAll('button[data-reject]').forEach(btn => {
      btn.addEventListener('click', async ()=>{
        const id = btn.getAttribute('data-reject');
        await fetch(`/api/admin/orders/${id}/reject`, {method:'PUT'});
        await loadOrders();
      });
    });
    ordersRoot.querySelectorAll('button[data-del]').forEach(btn => {
      btn.addEventListener('click', async ()=>{
        const id = btn.getAttribute('data-del');
        if(!confirm('تأكيد حذف الطلب؟')) return;
        await fetch(`/api/admin/orders/${id}`, {method:'DELETE'});
        await loadOrders();
      });
    });
  }

  groupSelect?.addEventListener('change', loadDesignsForSelectedGroup);

  await loadGroups();
  await loadDesignsForSelectedGroup();
  await loadOrders();
})();
